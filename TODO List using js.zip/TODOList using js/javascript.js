
function tackaction()
{
    const create= document.createElement('li')
    const store=document.getElementById('list')
    store.appendChild(create)
    create.textContent=document.getElementById('InputTask').value
    document.getElementById('InputTask').value=""
    deletebtn(create)
}
function deletebtn(create)
{
    const createbutton=document.createElement('button')
    createbutton.textContent="Completed"
    create.appendChild(createbutton)
    createbutton.onclick=function()
    {
        create.remove()
    }
}   